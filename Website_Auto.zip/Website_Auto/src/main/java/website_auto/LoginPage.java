package website_auto;


		import org.openqa.selenium.By;
		import org.openqa.selenium.WebDriver;
		import org.openqa.selenium.WebElement;

		public class LoginPage {
		    private WebDriver driver;

		    // Locators
		    private By usernameField = By.id("username");
		    private By passwordField = By.id("password");
		    private By loginButton = By.xpath("//button[@name='login']");

		    // Constructor
		    public LoginPage(WebDriver driver) {
		        this.driver = driver;
		    }

		    // Methods
		    public void enterUsername(String username) {
		        WebElement usernameElem = driver.findElement(usernameField);
		        usernameElem.sendKeys(username);
		    }

		    public void enterPassword(String password) {
		        WebElement passwordElem = driver.findElement(passwordField);
		        passwordElem.sendKeys(password);
		    }

		    public void clickLoginButton() {
		        WebElement loginBtn = driver.findElement(loginButton);
		        loginBtn.click();
		    }

		    public void login(String username, String password) {
		        enterUsername(username);
		        enterPassword(password);
		        clickLoginButton();
		    }
		}
