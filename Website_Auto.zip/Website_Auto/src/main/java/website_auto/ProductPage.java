package website_auto;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class ProductPage {
	
	private WebDriver driver;
	 

    // Locators
    private By Select_color= By.xpath("//*[@id=\"product-145\"]/div[3]/form/table/tbody/tr[1]/td/div/ul/li[1]/span");  // Update this if necessary
    private By Select_orientation  = By.xpath("//*[@id=\"product-145\"]/div[3]/form/table/tbody/tr[2]/td/div/ul/li[2]/span");  // Update this if necessary
    private By profileDescriptionField = By.id("profile_desc");  // Update this if necessary
    private By phoneNumberCheckbox = By.xpath("//*[@id=\"phone_number_checkbox\"]");  // Update this if necessary
    private By phoneNumberField = By.id("phone_number_field");  // Update this if necessary
    private By Select_idType = By.xpath("//*[@id=\"type\"]");  // Update this if necessary
   private By additionalElements = By.xpath("//*[@id=\"product-145\"]/div[3]/form/div/div[2]/div[2]/div[1]/h3");  // Update this if necessary
    private By uploadLogoField = By.xpath("//*[@id=\"logo\"]");  // Update this if necessary
    private By Select_Border1 =By.xpath("//*[@id=\"product-145\"]/div[3]/form/div/div[2]/div[2]/div[3]/div[2]/div[1]/label/div/img");
    private By Select_Border2 =By.xpath("//*[@id=\"product-145\"]/div[3]/form/div/div[2]/div[2]/div[3]/div[2]/div[3]/label/div/img");
    private By addToCartButton = By.xpath("//*[@id=\"product-145\"]/div[3]/form/div/div[2]/button");

    // Constructor
    public ProductPage(WebDriver driver) {
        this.driver = driver;
    }

    // Methods
    public void selectColor(String color) {
        driver.findElement(Select_color).click();
    }

    public void selectOrientation(String orientation) {
        driver.findElement(Select_orientation).click();
  
    }

    public void enterProfileDescription(String description) {
        WebElement descriptionElem = driver.findElement(profileDescriptionField);
        descriptionElem.sendKeys(description);
    }

    public void checkPhoneNumberCheckbox() {
       driver.findElement(phoneNumberCheckbox).click();
        
    }

    public void enterPhoneNumber(String phoneNumber) {
        WebElement phoneNumberElem = driver.findElement(phoneNumberField);
        phoneNumberElem.sendKeys(phoneNumber);
    }

    public void selectIDType(String idType) {
    	driver.findElement(Select_idType).click();
        Select idTypeSelect = new Select(driver.findElement(Select_idType));
        idTypeSelect.selectByVisibleText(idType);
    }

 
    public void uploadLogo(String filePath) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement uploadElem = wait.until(ExpectedConditions.elementToBeClickable(uploadLogoField));
        uploadElem.sendKeys(filePath);
        System.out.println("File uploaded: " + filePath);
    }

    public void selectBorder1() {
    	driver.findElement(Select_Border1 ).click();    
    }
    
    public void selectBorder2() {
    	driver.findElement(Select_Border2 ).click();    
    }
    
	public void clickAddToCart() {
        WebElement addToCartBtn = driver.findElement(addToCartButton);
        addToCartBtn.click();
    }
}
