package website_test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import website_auto.LoginPage;

public class LoginTest {
    private WebDriver driver;
    private LoginPage loginPage;

    
    @BeforeClass
    public void setUp() {
        // Set path to your ChromeDriver executable
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\jesee\\Desktop\\Testing\\Automation\\Chapters\\Selenium\\chromedriver-win32\\chromedriver.exe"); // Update the path
        driver = new ChromeDriver();
        driver.get("https://woocommerce-850415-2933260.cloudwaysapps.com/my-account");
        driver.manage().window().maximize();
        loginPage = new LoginPage(driver);
    }

    @Test
    public void testLogin() {
        loginPage.login("test_customer", "password");
        
    }

    @AfterClass
    public void tearDown() {
        //driver.quit();
    }
}