package website_test;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import website_auto.ProductPage;

public class ProductPageTest {
    private WebDriver driver;
    private ProductPage productPage;


    @BeforeClass
    public void setUp() {
        // Set path to your ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\jesee\\Desktop\\Testing\\Automation\\Chapters\\Selenium\\chromedriver-win32\\chromedriver.exe"); // Update path to chromedriver
        driver = new ChromeDriver();
        driver.get("https://woocommerce-850415-2933260.cloudwaysapps.com/product/rf-id-card");
        driver.manage().window().maximize();
        productPage = new ProductPage(driver);
    }

    @Test
    public void testProductPageFields() {
        productPage.selectColor("Red");
        productPage.selectOrientation("Landscape");
        productPage.enterProfileDescription("Happy pdt!");
        productPage.checkPhoneNumberCheckbox();
        productPage.enterPhoneNumber("9876543210");
        productPage.selectIDType("Premium ($50.00)");
        productPage.selectBorder1();
        productPage.selectBorder2();
        productPage.uploadLogo("C:\\Users\\jesee\\Desktop\\Zennode\\image.jpg"); // Update with the actual file path
        productPage.clickAddToCart();

        // Add assertion to verify product added to cart successfully
        String currentURL = driver.getCurrentUrl();
        Assert.assertTrue(currentURL.contains("rf-id-card"), "View cart“RF ID Card” has been added to your cart.");
    }
    
    @AfterClass
    public void tearDown() {
       // driver.quit();
    }

}
